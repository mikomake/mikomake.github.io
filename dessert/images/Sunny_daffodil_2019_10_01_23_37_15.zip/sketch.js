function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(255);
  strokeWeight(0);
  fill(mouseX, mouseY, mouseX);
  ellipse(200, 125, 200, 200);
  fill(255,255,255);
  rect(100, 150, 200, 200);
  fill(mouseX, mouseY, mouseX);
  ellipse(100, 140, 50, 50);
  ellipse(133, 140, 50, 50);
  ellipse(167, 140, 50, 50);
  ellipse(200, 140, 50, 50);
  ellipse(233, 140, 50, 50);
  ellipse(266, 140, 50, 50);
  ellipse(300, 140, 50, 50);
  fill(228, 176, 104);
  triangle(100, 170, 305, 170, 200, 400);
 
}